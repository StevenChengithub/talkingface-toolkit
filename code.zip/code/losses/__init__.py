from losses.freq_fourier_loss import *
from losses.freq_pixel_loss import *
