from stylegan2.stylegan2_arch import StyleGAN2Generator
from stylegan2.stylegan2_arch import *
from stylegan2.arcface_arch import  ResNetArcFace